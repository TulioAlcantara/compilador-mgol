# compilador-mgol

  Compilador da linguagem fictícia "Mgol", documentada neste [link.](https://turing.inf.ufg.br/pluginfile.php/15402/mod_resource/content/5/Descricao_trabalho1_Compiladores2020.pdf)
  
  
  Criado para a disciplina de Compiladores do curso de Ciências da Computação da Universidade Federal de Goiás

